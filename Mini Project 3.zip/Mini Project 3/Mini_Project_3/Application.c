/*
 *  Project: Fan controller
 *
 *  Created on: Apr 11, 2023
 *  Author: Eng.Hany Ashraf
 */

/*-----------------------------------------------------------------------------------------------------------*/
#include"adc.h"
#include"lcd.h"
#include"Motor.h"
#include"lm35_sensor.h"


/**********************************************Application Program***************************************/

int main(void)
{
	/*Auto Variable that reserve the value of Temp sensor*/
	uint8 temperature_sensor=0;
	/*Structure that Config. ADC peripheral*/
	ADC_ConfigType config = {INTERNAL_VOLTAGE,DIVIDE_8};
	/*Initialization of ADC*/
	ADC_init(&config);
	/*Initialization of LCD*/
	LCD_init();
	/*Initialization of DC_Motor*/
	DcMotor_Init();
	/*clear of LCD display*/
	LCD_clearScreen();
	while(1)
	{
		/*Function Call to get Temperature value*/
		temperature_sensor = LM35_getTemperature();

		/*Check if the Temp is less than 30 degree Fan will be OFF,
		 * Display the Temp. and Stop the Motor*/
		if(temperature_sensor < 30){

			LCD_displayString("Fan is OFF");
			LCD_displayStringRowColumn(1,0,"Temp = ");
			LCD_intgerToString(temperature_sensor);
			LCD_displayString(" C   ");
			LCD_moveCursor(0,0);
			DcMotor_Rotate(STOP,0);

		}
		/*Check if the Temp is within range of [30 : 60[ degree Fan will be ON,
		 * Display the Temp. and Run the Motor Clock Wise with 25% of speed*/
		else if(temperature_sensor >= 30 && temperature_sensor < 60)
		{

			LCD_displayString("Fan is ON ");
			LCD_displayStringRowColumn(1,0,"Temp = ");
			LCD_intgerToString(temperature_sensor);
			LCD_displayString(" C   ");
			LCD_moveCursor(0,0);
			DcMotor_Rotate(CLOCKWISE,25);
		}
		/*Check if the Temp is within range of [60 : 90[ degree Fan will be ON,
		 * Display the Temp. and Run the Motor Clock Wise with 50% of speed*/

		else if(temperature_sensor >= 60 && temperature_sensor < 90)
		{

			LCD_displayString("Fan is ON ");
			LCD_displayStringRowColumn(1,0,"Temp = ");
			LCD_intgerToString(temperature_sensor);
			LCD_displayString(" C  ");
			LCD_moveCursor(0,0);
			DcMotor_Rotate(CLOCKWISE,50);
		}
		/*Check if the Temp is within range of [90 : 120[ degree Fan will be ON,
		 * Display the Temp. and Run the Motor Clock Wise with 75% of speed*/

		else if(temperature_sensor >= 90 && temperature_sensor < 120)
		{

			LCD_displayString("Fan is ON ");
			LCD_displayStringRowColumn(1,0,"Temp = ");
			LCD_intgerToString(temperature_sensor);
			LCD_displayString(" C ");
			LCD_moveCursor(0,0);
			DcMotor_Rotate(CLOCKWISE,75);
		}
		/*Check if the Temp is within range of [120 : [ degree Fan will be ON,
		 * Display the Temp. and Run the Motor Clock Wise with 100% of speed*/

		else if(temperature_sensor >= 120)
		{

			LCD_displayString("Fan is ON ");
			LCD_displayStringRowColumn(1,0,"Temp = ");
			LCD_intgerToString(temperature_sensor);
			LCD_displayString(" C");
			LCD_moveCursor(0,0);
			DcMotor_Rotate(CLOCKWISE,100);
		}
	}

}
