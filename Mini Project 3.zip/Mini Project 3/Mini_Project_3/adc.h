 /******************************************************************************
 *
 * Module: ADC
 *
 * File Name: adc.h
 *
 * Description: header file for the ATmega32 ADC driver
 *
  *
 *******************************************************************************/

#ifndef ADC_H_
#define ADC_H_

#include "std_types.h"

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/
#define ADC_MAXIMUM_VALUE    1023
#define ADC_REF_VOLT_VALUE   5

/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/


typedef enum
{
	AREF, AVCC, INTERNAL_VOLTAGE
}ADC_ReferenceVolatge;

typedef enum
{
	DIVIDE_2 = 1, DIVIDE_4, DIVIDE_8, DIVIDE_16, DIVIDE_32, DIVIDE_64, DIVIDE_128
}ADC_Prescaler;

typedef struct{
	ADC_ReferenceVolatge REF_VOLT;
	ADC_Prescaler PRESCALAR;
}ADC_ConfigType;



void ADC_init(const ADC_ConfigType * Config_Ptr);


uint16 ADC_readChannel(uint8 channel_num);


#endif /* ADC_H_ */
