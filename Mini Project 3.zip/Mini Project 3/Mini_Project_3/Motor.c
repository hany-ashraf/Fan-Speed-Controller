/*
 * Module: MOTOR
 * File Name: Motor.c
 * Description: Source file for the Motor driver
 *
 */

#include<avr/io.h>
#include"Motor.h"
#include"pwm.h"
#include"gpio.h"


void DcMotor_Init(void)
{

	/* configure pin PC0 and PC1 as output pins */
	 GPIO_setupPinDirection(PORT_DC_MOTOR,FIRST_PIN_MOTOR_DIRECTION, PIN_OUTPUT);
	 GPIO_setupPinDirection(PORT_DC_MOTOR,SECOND_PIN_MOTOR_DIRECTION, PIN_OUTPUT);

	/* Motor is stop at the beginning */
	 GPIO_writePin(PORT_DC_MOTOR,FIRST_PIN_MOTOR_DIRECTION, LOGIC_LOW);
	 GPIO_writePin(PORT_DC_MOTOR,SECOND_PIN_MOTOR_DIRECTION, LOGIC_LOW);
}



void DcMotor_Rotate(uint8 state,uint8 speed)
{

	PWM_Timer0_Init(speed);


	if(state == 0)
	{
		 GPIO_writePin(PORT_DC_MOTOR,FIRST_PIN_MOTOR_DIRECTION, LOGIC_LOW);
		 GPIO_writePin(PORT_DC_MOTOR,SECOND_PIN_MOTOR_DIRECTION, LOGIC_LOW);
	}
	else if(state == 1)
	{
		 GPIO_writePin(PORT_DC_MOTOR,FIRST_PIN_MOTOR_DIRECTION, LOGIC_HIGH);
		 GPIO_writePin(PORT_DC_MOTOR,SECOND_PIN_MOTOR_DIRECTION, LOGIC_LOW);
	}
	else if(state == 2)
	{
		 GPIO_writePin(PORT_DC_MOTOR,FIRST_PIN_MOTOR_DIRECTION, LOGIC_LOW);
		 GPIO_writePin(PORT_DC_MOTOR,SECOND_PIN_MOTOR_DIRECTION, LOGIC_HIGH);
	}


}
