/*
 * pwm.h
 *
 *  Created on: Apr 11, 2023
 *      Author: Eng.Hany Ashraf
 */


#ifndef PWM_H_
#define PWM_H_


#include "std_types.h"

void PWM_Timer0_Init(unsigned char set_duty_cycle);


#endif /* PWM_H_ */
