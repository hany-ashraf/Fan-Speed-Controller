/*
 * Module: MOTOR
 * File Name: Motor.h
 * Description: Header file for the Motor driver
 *
 */

#include "std_types.h"



#define PORT_DC_MOTOR    PORTB_ID


#define FIRST_PIN_MOTOR_DIRECTION   PIN0_ID
#define SECOND_PIN_MOTOR_DIRECTION  PIN1_ID
#define PIN_VOLTAGE_CONTROLLER      PIN3_ID


enum state
{
	STOP, CLOCKWISE, ANTI_CLOCKWISE
};


void DcMotor_Init(void);

void DcMotor_Rotate(uint8 state,uint8 speed);



